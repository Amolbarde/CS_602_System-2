#include <iostream>
#include <fstream>
#include <string>
#include <cctype>
using namespace std;
bool isRegister(string op)
{
    string reg[] = {
        "EAX", "ECX", "EDX", "EBX",
        "ESP", "EBP", "ESI", "EDI"
    };
    for (int i = 0; i < 8; i++)
    {
        if (op == reg[i])
            return true;
    }

    return false;
}
bool isConstant(string op)
{
    if (op.empty())
        return false;

    for (int i = 0; i < op.length(); i++)
    {
        if (!isdigit(op[i]))
            return false;
    }
    return true;
}
bool isMemory(string op)
{
    if (op.length() >= 2 &&
        op[0] == '[' &&
        op[op.length() - 1] == ']')
        return true;

    return false;
}
bool isSymbol(string op, string symbol[], int count)
{
    for (int i = 0; i < count; i++)
    {
        if (op == symbol[i])
            return true;
    }
    return false;
}
string getType(string op, string symbol[], int count)
{
    if (isRegister(op))
        return "Register";

    if (isConstant(op))
        return "Constant";
    if (isMemory(op))
        return "Memory";

    if (isSymbol(op, symbol, count))
        return "Symbol";

    return "Unknown";
}
bool isOpcode(string mnemonic, string opcode[], int count)
{
    for (int i = 0; i < count; i++)
    {
        if (mnemonic == opcode[i])
            return true;
    }

    return false;
}

int main()
{
    ifstream opcodeFile("opcode.txt");
    ifstream assemblyFile("assembly.txt");

    if (!opcodeFile || !assemblyFile)
    {
        cout << "File not found!";
        return 0;
    }

    string opcode[100];
    string word, code;
    int opcodeCount = 0;

    while (opcodeFile >> word >> code)
    {
        opcode[opcodeCount] = word;
        opcodeCount++;
    }

    string symbol[100];
    int symbolCount = 0;

    string line;
    while (getline(assemblyFile, line))
    {
        if (line.empty())
            continue;

        if (line.find("main") != string::npos)
            break;

        int colon = line.find(':');
        if (colon != string::npos)
        {
            string label = line.substr(0, colon);
            symbol[symbolCount] = label;
            symbolCount++;
            continue;
        }

        int space = line.find(' ');
        if (space != string::npos)
        {
            string name = line.substr(0, space);
            if (name != "section")
            {
                symbol[symbolCount] = name;
                symbolCount++;
            }
        }
    }
    cout << "\nSYMBOL TABLE\n";
    cout << "------------\n";
    for (int i = 0; i < symbolCount; i++)
        cout << symbol[i] << endl;
    cout << "\nOPCODE CHECK\n";
    cout << "------------------------------------------------\n";
    cout << "Mnemonic\tFound\tOperand\t\tType\n";
    cout << "------------------------------------------------\n";
    while (getline(assemblyFile, line))
    {
        if (line.empty())
            continue;

        int colon = line.find(':');
        if (colon != string::npos)
        {
            string label = line.substr(0, colon);
            bool exists = false;
            for (int i = 0; i < symbolCount; i++)
            {
                if (symbol[i] == label)
                    exists = true;
            }
            if (!exists)
            {
                symbol[symbolCount] = label;
                symbolCount++;
            }
            if (colon == line.length() - 1)
                continue;
            line = line.substr(colon + 1);
            if (!line.empty() && line[0] == ' ')
                line = line.substr(1);
        }

        int space = line.find(' ');
        if (space == string::npos)
            continue;
        string mnemonic = line.substr(0, space);
        string operands = line.substr(space + 1);
        bool found = isOpcode(
            mnemonic,
            opcode,
            opcodeCount
        );

        int comma = operands.find(',');

        if (comma == string::npos)
        {
            string op1 = operands;

            if (!op1.empty() && op1[0] == ' ')
                op1 = op1.substr(1);

            cout << mnemonic << "\t\t"
                 << (found ? "YES" : "NO") << "\t"
                 << op1 << "\t\t"
                 << getType(op1, symbol, symbolCount)
                 << endl;
        }
        else
        {
            string op1 = operands.substr(0, comma);
            string op2 = operands.substr(comma + 1);

            if (!op1.empty() && op1[op1.length() - 1] == ' ')
                op1.pop_back();

            if (!op2.empty() && op2[0] == ' ')
                op2 = op2.substr(1);

            cout << mnemonic << "\t\t"
                 << (found ? "YES" : "NO") << "\t"
                 << op1 << "\t\t"
                 << getType(op1, symbol, symbolCount)
                 << endl;

            cout << mnemonic << "\t\t"
                 << (found ? "YES" : "NO") << "\t"
                 << op2 << "\t\t"
                 << getType(op2, symbol, symbolCount)
                 << endl;
        }
    }
    opcodeFile.close();
    assemblyFile.close();
    return 0;
}
