Assignment 5 - Five Flag Simulation
===================================

Reference used:
- Assignment-3/main.cpp for opcode lookup and operand type checking.
- Assignment-3/opcode.txt for opcode entries.
- Assignment-3/assembly.txt as the sample assembly input.

Files:
- main.cpp: one C++ source file; simulates CF, ZF, SF, OF, and PF for ADD and SUB.
- opcode.txt: opcode list copied from the reference assignment.
- assembly.txt: sample input copied from the reference assignment.

Compile and run (Ubuntu):
    g++ -std=c++17 main.cpp -o main
    ./main

Note:
This is a simple educational simulation. It does not execute IA-32 machine code or modify the real CPU EFLAGS register. The flags are updated for the ADD and SUB operations simulated by this program. Opcode table entries are taken from the provided reference file.
